The program is to be compiled on dijkstra as following:
g++ -o hw2 -std=c++11 *.cpp
./hw2 input.txt 4